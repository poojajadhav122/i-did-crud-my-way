<?php
require_once "connection.php";
//print_r($_POST);
if(empty($_POST['firstname'])){
	echo "invalid  first name";
}
elseif (empty($_POST['lastname'])) {
	echo "invalid last name";
}
else{
	$first =$_POST['firstname'];
	$last =$_POST['lastname'];
	$str = "insert into user(firstname,lastname) values('$first','$last')";
	echo $str;
	$res = $conn->query($str) or die($conn->error);
	print_r($res);
	echo "user added";
}

?>