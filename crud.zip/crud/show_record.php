<?php
require_once "connection.php";
$str = "select * from user";
echo $str;
$res = $conn->query($str) or die($conn->error);
print_r($res);


?>
<div class="conatainer">
	<div class="row">
		<a href="index.php"> go back</a>
		<table class="table">
       <tr>
       	<th>id</th>
       	<th>firstname</th>
       	<th>lastname</th>
       	<th>action</th>
       </tr>
       <?php
      while($ans=$res->fetch_assoc()){

       ?>	
       <tr>
       	<td><?php echo  $ans['id']?></td>
       	<td><?php echo $ans['firstname']?></td>
       	<td><?php echo $ans['lastname']?></td>
       	<td><a href="edit.php?ab=<?php echo $ans['id']?>">edit</a></td>
       	<td><a href="delete.php?ab=<?php echo $ans['id']?>">delete</a></td>
       </tr>
       <?php
        }
       ?>		
		</table>
	</div>
	
</div>