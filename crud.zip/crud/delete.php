<?php
require_once ("connection.php");
$uid =$_GET['ab'];
$str = "delete from user where id = '$uid'";
echo $str;
$res = $conn->query($str) or die($conn->error);
print_r($res);
header("location:show_record.php")
?>