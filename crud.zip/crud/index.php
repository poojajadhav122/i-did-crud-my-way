<?php 
	require_once "connection.php";

?>
<div class="container">
	<form id="user_form">
	<label>FIRST NAME</label>
	<input type="text" name="firstname" placeholder="Enter first name">
	<br>
	<label> LAST NAME</label>
	<input type="text" name="lastname" placeholder="Enter last name">
	<br>
	<button type="button" class="btn_user">enter</button>
	<div class="msg_form"></div>
	</form>
	<a href="show_record.php">Show records</a>
</div>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/form1.js"></script>
