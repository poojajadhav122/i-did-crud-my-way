//alert("load form")
$(document).ready(function(){
	//alert("jquery")
	$(".btn_user").click(function(){
		alert("on click")
		var data = $("#user_form").serialize();
		console.log(data)
		$.post("add-action.php",data,function(response){
			console.log(response);
			$(".msg_form").html(response)
		})
	})


	$(".btn_edit").click(function(){
		alert("on click")
		var data = $("#edit_form").serialize();
		console.log(data)
		$.post("update-action.php",data,function(response){
			console.log(response);
			$(".msg_form1").html(response)
		})
	})
})