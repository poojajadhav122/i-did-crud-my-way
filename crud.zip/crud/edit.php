<?php 
	require_once "connection.php";
	$uid =$_GET['ab'];
	$str = "select * from user where id ='$uid'";
	echo $str;
	$res = $conn->query($str) or die($conn->error);
	print_r($res);
	$ans=$res->fetch_assoc();
	print_r($ans);

?>

<div class="container">
	<form id="edit_form">
	<label>FIRST NAME</label>
	<input type="text" name="firstname"   value="<?php echo $ans['firstname'] ?>" placeholder="Enter first name">
	<br>
	
	<label> LAST NAME</label>
	<input type="text" name="lastname"   value="<?php echo $ans['lastname']?>" placeholder="Enter last name">
	<br>
	<input type="text" name="id"   value="<?php echo $ans['id']?>" placeholder="Enter last name">
	<br>
	<button type="button" class="btn_edit">update</button>
	<div class="msg_form1"></div>
	</form>
	
</div>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/form1.js"></script>
