<?php
require_once ("connection.php");
print_r($_POST);
if(empty($_POST['firstname'])){
	echo "invalid first name";

}
elseif (empty($_POST['lastname'])) {
	echo "invalid last name";
}
else{
	$first = $_POST['firstname'];
	$last =$_POST['lastname'];
	$id =$_POST['id'];
	$str = "update user set firstname='$first',lastname='$last' where id = '$id'";
	echo $str;
	$res = $conn->query($str) or die($conn->error);
	print_r($res);
	echo "new data updated";
	//header("location:showdata.php");
}


?>